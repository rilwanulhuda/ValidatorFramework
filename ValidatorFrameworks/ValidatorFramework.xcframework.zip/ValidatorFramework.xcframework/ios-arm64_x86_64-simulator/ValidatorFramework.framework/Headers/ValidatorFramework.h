//
//  ValidatorFramework.h
//  ValidatorFramework
//
//  Created by Rilwanul Huda on 04/04/23.
//

#import <Foundation/Foundation.h>

//! Project version number for ValidatorFramework.
FOUNDATION_EXPORT double ValidatorFrameworkVersionNumber;

//! Project version string for ValidatorFramework.
FOUNDATION_EXPORT const unsigned char ValidatorFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ValidatorFramework/PublicHeader.h>


